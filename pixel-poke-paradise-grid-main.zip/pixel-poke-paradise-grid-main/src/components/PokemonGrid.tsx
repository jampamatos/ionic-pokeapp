
import React, { useEffect, useState, useRef } from 'react';
import PokemonCard from './PokemonCard';

interface PokemonGridProps {
  searchTerm: string;
  currentPage: number;
  showFavorites: boolean;
  favorites: number[];
  onToggleFavorite: (id: number) => void;
}

// Mock data for demonstration
const mockPokemon = Array.from({ length: 150 }, (_, i) => ({
  id: i + 1,
  name: `Pokemon ${i + 1}`,
  type1: ['Fire', 'Water', 'Grass', 'Electric', 'Psychic', 'Ice', 'Dragon', 'Dark'][i % 8],
  type2: i % 3 === 0 ? ['Flying', 'Poison', 'Ground', 'Rock'][i % 4] : null,
}));

const PokemonGrid = ({ searchTerm, currentPage, showFavorites, favorites, onToggleFavorite }: PokemonGridProps) => {
  const itemsPerPage = 4; // Always 4 cards in 2x2 grid
  const gridRef = useRef<HTMLDivElement>(null);
  
  let filteredPokemon = mockPokemon;
  
  // Filter by search term
  if (searchTerm) {
    filteredPokemon = filteredPokemon.filter(pokemon =>
      pokemon.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }
  
  // Filter by favorites if needed
  if (showFavorites) {
    filteredPokemon = filteredPokemon.filter(pokemon => favorites.includes(pokemon.id));
  }
  
  // Paginate
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentPokemon = filteredPokemon.slice(startIndex, startIndex + itemsPerPage);

  if (currentPokemon.length === 0) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-600 text-center">
          <p className="text-gray-300 text-sm">
            {showFavorites ? 'No favorite Pokémon yet!' : 'No Pokémon found!'}
          </p>
          <p className="text-gray-500 text-xs mt-1">
            {showFavorites ? 'Add some Pokémon to your favorites!' : 'Try a different search term.'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div 
      ref={gridRef}
      className="h-full grid grid-cols-2 grid-rows-2 gap-2 p-2"
    >
      {currentPokemon.map((pokemon) => (
        <PokemonCard
          key={pokemon.id}
          pokemon={pokemon}
          isFavorite={favorites.includes(pokemon.id)}
          onToggleFavorite={() => onToggleFavorite(pokemon.id)}
        />
      ))}
    </div>
  );
};

export default PokemonGrid;
