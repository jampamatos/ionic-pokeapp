
import React from 'react';
import { Star } from 'lucide-react';

interface Pokemon {
  id: number;
  name: string;
  type1: string;
  type2?: string | null;
}

interface PokemonCardProps {
  pokemon: Pokemon;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

const typeColors: { [key: string]: string } = {
  Fire: 'from-red-600 to-red-800',
  Water: 'from-blue-600 to-blue-800',
  Grass: 'from-green-600 to-green-800',
  Electric: 'from-yellow-500 to-yellow-700',
  Psychic: 'from-pink-600 to-pink-800',
  Ice: 'from-cyan-500 to-cyan-700',
  Dragon: 'from-purple-600 to-purple-800',
  Dark: 'from-gray-700 to-gray-900',
  Flying: 'from-indigo-500 to-indigo-700',
  Poison: 'from-purple-500 to-purple-700',
  Ground: 'from-yellow-700 to-yellow-900',
  Rock: 'from-yellow-800 to-yellow-900',
};

const PokemonCard = ({ pokemon, isFavorite, onToggleFavorite }: PokemonCardProps) => {
  return (
    <div className="bg-gray-900 rounded border-2 border-green-600/50 hover:border-green-400 transition-all duration-200 overflow-hidden relative shadow-lg"
         style={{
           fontFamily: 'Monaco, "Lucida Console", monospace',
           boxShadow: 'inset 0 1px 2px rgba(0,255,0,0.1), 0 0 8px rgba(0,0,0,0.5)'
         }}>
      {/* Pokemon Image Placeholder */}
      <div className={`bg-gradient-to-br ${typeColors[pokemon.type1] || 'from-gray-700 to-gray-900'} h-20 flex items-center justify-center relative border-b border-green-600/30`}>
        <div className="text-2xl opacity-70">🎮</div>
        {/* Pixelated overlay effect */}
        <div className="absolute inset-0 bg-black/20" 
             style={{
               backgroundImage: 'repeating-conic-gradient(#000 0% 25%, transparent 0% 50%) 50% / 4px 4px'
             }}></div>
        <button
          onClick={onToggleFavorite}
          className={`absolute top-1 right-1 p-1 rounded border transition-all duration-200 ${
            isFavorite 
              ? 'bg-yellow-400 text-black border-yellow-600' 
              : 'bg-gray-800 text-green-400 border-green-600 hover:bg-green-900'
          }`}
        >
          <Star size={8} fill={isFavorite ? 'currentColor' : 'none'} />
        </button>
      </div>
      
      {/* Pokemon Info */}
      <div className="p-2 bg-black">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-bold text-[10px] text-green-400 truncate uppercase tracking-wide">{pokemon.name}</h3>
          <span className="text-[8px] text-green-600 font-mono">#{pokemon.id.toString().padStart(3, '0')}</span>
        </div>
        
        {/* Types */}
        <div className="flex gap-1">
          <span className={`px-2 py-0.5 rounded text-white text-[8px] font-bold uppercase tracking-wider border bg-gradient-to-r ${typeColors[pokemon.type1] || 'from-gray-600 to-gray-800'}`}>
            {pokemon.type1}
          </span>
          {pokemon.type2 && (
            <span className={`px-2 py-0.5 rounded text-white text-[8px] font-bold uppercase tracking-wider border bg-gradient-to-r ${typeColors[pokemon.type2] || 'from-gray-600 to-gray-800'}`}>
              {pokemon.type2}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default PokemonCard;
