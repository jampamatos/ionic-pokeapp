
import React from 'react';
import { Star } from 'lucide-react';

interface FavoritesToggleProps {
  showFavorites: boolean;
  onToggle: () => void;
  favoriteCount: number;
}

const FavoritesToggle = ({ showFavorites, onToggle, favoriteCount }: FavoritesToggleProps) => {
  return (
    <button
      onClick={onToggle}
      className={`flex items-center gap-2 px-3 py-1 rounded border-2 font-bold text-[10px] transition-all duration-200 uppercase tracking-wider ${
        showFavorites
          ? 'bg-yellow-600 text-black border-yellow-800 shadow-inner'
          : 'bg-gray-900 text-green-400 border-green-600 hover:border-green-400 hover:bg-green-900/50'
      }`}
      style={{ 
        fontFamily: 'Monaco, "Lucida Console", monospace',
        boxShadow: showFavorites ? 'inset 0 2px 4px rgba(0,0,0,0.3)' : '0 0 8px rgba(0,255,0,0.3)'
      }}
    >
      <Star size={10} fill={showFavorites ? 'currentColor' : 'none'} />
      <span>
        {showFavorites ? 'ALL' : 'FAVS'}
      </span>
      {favoriteCount > 0 && (
        <span className={`px-1 py-0.5 rounded text-[8px] font-bold ${
          showFavorites ? 'bg-yellow-800 text-yellow-100' : 'bg-green-600 text-black'
        }`}>
          {favoriteCount}
        </span>
      )}
    </button>
  );
};

export default FavoritesToggle;
