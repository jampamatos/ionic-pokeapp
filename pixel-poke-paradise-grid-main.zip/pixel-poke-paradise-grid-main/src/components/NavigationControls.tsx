
import React from 'react';
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';

interface NavigationControlsProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

const NavigationControls = ({ currentPage, totalPages, onPageChange }: NavigationControlsProps) => {
  const canGoPrevious = currentPage > 1;
  const canGoNext = currentPage < totalPages;

  return (
    <div className="relative w-16 h-16">
      {/* D-Pad Base */}
      <div className="absolute inset-0 bg-gradient-to-b from-gray-600 to-gray-800 rounded-lg border-2 border-black shadow-lg"
           style={{
             boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.3), 0 4px 8px rgba(0,0,0,0.4)'
           }}>
        
        {/* Vertical Bar */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-6 h-full bg-gradient-to-b from-gray-500 to-gray-700 rounded-lg border border-gray-800"></div>
        
        {/* Horizontal Bar */}
        <div className="absolute top-1/2 left-0 transform -translate-y-1/2 w-full h-6 bg-gradient-to-r from-gray-500 to-gray-700 rounded-lg border border-gray-800"></div>

        {/* Up Button */}
        <button
          onClick={() => onPageChange(Math.min(currentPage + 1, totalPages))}
          disabled={!canGoNext}
          className={`absolute top-1 left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-sm transition-all duration-150 flex items-center justify-center border ${
            canGoNext 
              ? 'bg-gray-400 hover:bg-gray-300 active:bg-gray-600 text-black border-gray-600 shadow-sm' 
              : 'bg-gray-800 text-gray-600 cursor-not-allowed border-gray-900'
          }`}
        >
          <ChevronUp size={10} />
        </button>

        {/* Down Button */}
        <button
          onClick={() => onPageChange(Math.max(currentPage - 1, 1))}
          disabled={!canGoPrevious}
          className={`absolute bottom-1 left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-sm transition-all duration-150 flex items-center justify-center border ${
            canGoPrevious 
              ? 'bg-gray-400 hover:bg-gray-300 active:bg-gray-600 text-black border-gray-600 shadow-sm' 
              : 'bg-gray-800 text-gray-600 cursor-not-allowed border-gray-900'
          }`}
        >
          <ChevronDown size={10} />
        </button>

        {/* Left Button */}
        <button
          onClick={() => onPageChange(Math.max(currentPage - 1, 1))}
          disabled={!canGoPrevious}
          className={`absolute top-1/2 left-1 transform -translate-y-1/2 w-4 h-4 rounded-sm transition-all duration-150 flex items-center justify-center border ${
            canGoPrevious 
              ? 'bg-gray-400 hover:bg-gray-300 active:bg-gray-600 text-black border-gray-600 shadow-sm' 
              : 'bg-gray-800 text-gray-600 cursor-not-allowed border-gray-900'
          }`}
        >
          <ChevronLeft size={10} />
        </button>

        {/* Right Button */}
        <button
          onClick={() => onPageChange(Math.min(currentPage + 1, totalPages))}
          disabled={!canGoNext}
          className={`absolute top-1/2 right-1 transform -translate-y-1/2 w-4 h-4 rounded-sm transition-all duration-150 flex items-center justify-center border ${
            canGoNext 
              ? 'bg-gray-400 hover:bg-gray-300 active:bg-gray-600 text-black border-gray-600 shadow-sm' 
              : 'bg-gray-800 text-gray-600 cursor-not-allowed border-gray-900'
          }`}
        >
          <ChevronRight size={10} />
        </button>

        {/* Center Circle (Page Indicator) */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-black rounded-full border border-gray-600 flex items-center justify-center shadow-inner">
          <div className="text-[6px] font-bold text-green-400" style={{ fontFamily: 'Monaco, "Lucida Console", monospace' }}>{currentPage}</div>
        </div>
      </div>
    </div>
  );
};

export default NavigationControls;
