
import React, { useState } from 'react';
import { Search } from 'lucide-react';

interface SearchBarProps {
  onSearch: (term: string) => void;
}

const SearchBar = ({ onSearch }: SearchBarProps) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchTerm);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    onSearch(value); // Real-time search
  };

  return (
    <form onSubmit={handleSubmit} className="relative">
      <div className="relative">
        <input
          type="text"
          value={searchTerm}
          onChange={handleChange}
          placeholder="SEARCH POKEMON..."
          className="w-full px-3 py-2 pl-8 text-xs rounded border-2 border-green-600 bg-black text-green-400 placeholder-green-600/60 focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-green-400 transition-all duration-200 shadow-inner"
          style={{ 
            fontFamily: 'Monaco, "Lucida Console", monospace',
            textTransform: 'uppercase',
            letterSpacing: '1px'
          }}
        />
        <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-green-600" size={12} />
        {/* Retro input styling */}
        <div className="absolute inset-0 rounded border border-green-400/20 pointer-events-none"></div>
      </div>
    </form>
  );
};

export default SearchBar;
