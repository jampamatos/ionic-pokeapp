import React, { useState } from 'react';
import SearchBar from '../components/SearchBar';
import PokemonGrid from '../components/PokemonGrid';
import NavigationControls from '../components/NavigationControls';
import FavoritesToggle from '../components/FavoritesToggle';

const Index = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [showFavorites, setShowFavorites] = useState(false);
  const [favorites, setFavorites] = useState<number[]>([]);

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    setCurrentPage(1); // Reset to first page on new search
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const toggleFavorite = (pokemonId: number) => {
    setFavorites(prev => 
      prev.includes(pokemonId) 
        ? prev.filter(id => id !== pokemonId)
        : [...prev, pokemonId]
    );
  };

  return (
    <div className="min-h-screen bg-gray-600 flex items-center justify-center p-4">
      {/* Pokédex Device Frame */}
      <div className="relative w-full max-w-md mx-auto">
        {/* Device Body */}
        <div className="bg-gradient-to-b from-red-500 to-red-700 rounded-t-3xl rounded-b-2xl shadow-2xl border-4 border-black p-6 relative overflow-hidden" 
             style={{ 
               boxShadow: 'inset 0 4px 8px rgba(0,0,0,0.3), 0 8px 16px rgba(0,0,0,0.4)',
               fontFamily: 'monospace'
             }}>
          
          {/* Top Section with Blue Circle and Indicator Lights */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 bg-gradient-to-br from-cyan-300 to-blue-600 rounded-full border-4 border-white shadow-inner relative">
                <div className="absolute inset-2 bg-gradient-to-br from-blue-400 to-cyan-700 rounded-full"></div>
                <div className="absolute top-2 left-2 w-3 h-3 bg-white/60 rounded-full"></div>
                <div className="absolute inset-3 border-2 border-white/30 rounded-full"></div>
              </div>
            </div>
            <div className="flex gap-2">
              <div className="w-3 h-3 bg-yellow-400 rounded-full border-2 border-yellow-700 shadow-inner animate-pulse" style={{ animationDuration: '2s' }}></div>
              <div className="w-3 h-3 bg-red-400 rounded-full border-2 border-red-700 shadow-inner"></div>
              <div className="w-3 h-3 bg-green-400 rounded-full border-2 border-green-700 shadow-inner animate-pulse" style={{ animationDuration: '1.5s' }}></div>
            </div>
          </div>

          {/* Screen Frame */}
          <div className="bg-gray-900 rounded-lg border-4 border-gray-700 p-1 mb-6 relative shadow-inner">
            <div className="bg-black rounded border-2 border-gray-800 p-3 relative min-h-[400px] max-h-[500px] overflow-hidden">
              {/* CRT Screen Effect Lines */}
              <div className="absolute inset-0 bg-gradient-to-b from-transparent via-green-500/5 to-transparent opacity-30 pointer-events-none"
                   style={{
                     backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,0,0.1) 2px, rgba(0,255,0,0.1) 4px)'
                   }}></div>
              
              {/* Screen Content */}
              <div className="relative z-10 h-full flex flex-col" 
                   style={{ 
                     fontFamily: 'Monaco, "Lucida Console", monospace',
                     fontSize: '12px'
                   }}>
                {/* Header */}
                <div className="text-center mb-3 border-b border-green-400/30 pb-2">
                  <div className="text-green-400 text-xs font-bold tracking-wider">POKÉDEX v2.0</div>
                  <div className="text-green-300/70 text-[10px] mt-1">◆◇◆ GOTTA CATCH 'EM ALL ◆◇◆</div>
                </div>

                {/* Search Bar */}
                <div className="mb-3">
                  <SearchBar onSearch={handleSearch} />
                </div>

                {/* Favorites Toggle */}
                <div className="mb-3 flex justify-center">
                  <FavoritesToggle 
                    showFavorites={showFavorites} 
                    onToggle={() => setShowFavorites(!showFavorites)}
                    favoriteCount={favorites.length}
                  />
                </div>

                {/* Pokemon Grid - Flex grow to fill remaining space */}
                <div className="flex-1 overflow-hidden">
                  <PokemonGrid 
                    searchTerm={searchTerm}
                    currentPage={currentPage}
                    showFavorites={showFavorites}
                    favorites={favorites}
                    onToggleFavorite={toggleFavorite}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Control Panel */}
          <div className="flex items-center justify-between">
            {/* Left Side - Red Button and Speaker */}
            <div className="flex flex-col items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-b from-red-400 to-red-700 rounded-full border-4 border-red-900 shadow-lg cursor-pointer active:scale-95 transition-transform relative"
                   onClick={() => setShowFavorites(!showFavorites)}>
                <div className="absolute inset-1 bg-gradient-to-t from-red-700 to-red-400 rounded-full"></div>
                <div className="absolute inset-2 bg-red-600 rounded-full shadow-inner"></div>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1 h-1 bg-red-900 rounded-full"></div>
              </div>
              <div className="flex gap-1">
                {[1,2,3,4].map(i => (
                  <div key={i} className="w-6 h-1 bg-gray-900 rounded-full border border-gray-700"></div>
                ))}
              </div>
            </div>

            {/* Center - Green Rectangle Button */}
            <div className="w-20 h-12 bg-gradient-to-b from-green-400 to-green-700 rounded border-4 border-green-900 shadow-lg cursor-pointer active:scale-95 transition-transform flex items-center justify-center relative"
                 onClick={() => handlePageChange(1)}>
              <div className="absolute inset-1 bg-gradient-to-t from-green-700 to-green-500 rounded"></div>
              <div className="text-[10px] font-bold text-green-900 relative z-10 tracking-wider">RESET</div>
            </div>

            {/* Right Side - D-Pad */}
            <NavigationControls 
              currentPage={currentPage}
              onPageChange={handlePageChange}
              totalPages={15}
            />
          </div>

          {/* Bottom Edge Detail */}
          <div className="absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-b from-red-700 to-red-900 rounded-b-2xl"></div>
        </div>

        {/* Device Shadow */}
        <div className="absolute inset-0 bg-black/30 rounded-3xl transform translate-y-3 translate-x-2 -z-10 blur-sm"></div>
      </div>
    </div>
  );
};

export default Index;
